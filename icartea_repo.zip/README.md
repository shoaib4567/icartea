# icartea Project

This is a simple web project that includes an anchor link to [icartea.com](https://icartea.com) with the anchor text **"cartea"**.

## Files

- `index.html`: Contains the main webpage.